#!/usr/bin/env python3
from simple_pid import PID
import rospy, time
from std_msgs.msg import String, Int16, Int16MultiArray, Int32MultiArray, Int8
import steering
from modules.pid import PID
import time
from modules.rgb import Color, RGB
from modules.button import Button
import RPi.GPIO as GPIO

state = 0

def change_state(channel):
    global state

    rospy.loginfo("previous state:" + str(state) + ", channel: " + str(channel))
    if state == 0:
        state = 1
    else:
        state = 0
    



encoder = Int32MultiArray() # left_encoder, main_encoder, right_encoder
encoder.data = [0, 0, 0]
# pillar_array.data = ["color", "cx", "cy", "height", "center"]
pillar = Int16MultiArray()
pillar.data = [0, 0, 0, 0, 0]
left_distance = right_distance = 0
gyro_pos = 0
first_line = 0
on_turn = False
line = 0

steer = steering.Steering()
reference_angle = 0



pub = rospy.Publisher('speed', String, queue_size=10)

def line_callback(data):
    global line

    if not on_turn:
        rospy.loginfo(rospy.get_caller_id() + "Line %s", data.data)
        line = data.data
    

def reset_gyro_angle():
    global reference_angle

    reference_angle = gyro_pos

def read_angle():
    return reference_angle - gyro_pos



def distance_callback(data):
    global left_distance, right_distance

    #rospy.loginfo(rospy.get_caller_id() + "Distances %s", data.data)
    left_distance = data.data[0]
    right_distance = data.data[1]
    # print("LD: ", left_distance)
    # print("RD: ", right_distance)


def gyro_callback(data):
    global gyro_pos

    #rospy.loginfo(rospy.get_caller_id() + "Gyro angle %s", str(data.data))
    gyro_pos = data.data


def encoders_callback(data):
    global encoder

    #rospy.loginfo(rospy.get_caller_id() + "Encoders %s", data.data)
    encoder = data
    # print("Encoder: ", encoder.data)

def pillar_callback(data):
    global pillar

    # rospy.loginfo(rospy.get_caller_id() + "Pillar %s", data.data)
    pillar = data
    # print("Pillar: ", pillar.data)

    
def dc_speed(speed=0):
    msg = str(speed)
    rospy.loginfo(msg)
    pub.publish(msg)

def turn(angle):
    global do_turn

    print("start steering in demo turn function")
    time.sleep(0.5)
    print("stop steering in demo turn function")
    do_turn = False

def get_target(color, center, height, kc=1, kh=1, min_center=15):
    center = (center + 100) // 2
    if color == 1 and center > min_center:
        t = kc * center + (kh * 100 * height)/300
        # print("t:", t)
        return min(max(-100, int(t)), 100)
    if color == -1 and center < 100 - min_center:
        t = kc * (100 - center) + (kh * 100 * height)/300
        # print("t:", t)
        return -1 * min(max(-100, int(t)), 100)
    
    return None

def drive(speed=50, main_position=0, pid_ks=(1, 0, 0)):
    global line, on_turn, state

    # Initialise PID object
    pid = PID(pid_ks[0], pid_ks[1], pid_ks[2])
    pid.SetPoint = 0
    pid.setSampleTime(0.005)
    dc_speed(speed)
    gyro_target = main_position
    turns = 0
    last_turn_ticks = 0
    last_wall_turn_ticks = 0
    last_pillar_turn_ticks = 0
    turn_min_ticks = 14000 
    min_wall_distance = 120
    wall_ticks_threshold = 0
    pillar_ticks_threshold = 800
    last_pillar = 0
    while not rospy.is_shutdown() and state > 0 and turns < 13:
        # 1st step: check if you need to change gyro target (turn left or right)
        gyro_error = gyro_target - read_angle()
        ld = left_distance
        rd = right_distance
        l = line
        turn_left = turn_right = False
        turn_left = (ld > 2000 and abs(gyro_error) < 10) or l < 0     
        # rospy.loginfo("ld:" + str(left_distance) + ", gyro_error:" + str(gyro_error) + ", turn: " + str(turn_left)) 
        # rospy.loginfo("encoder.data[1] - last_turn_ticks:" + str(encoder.data[1] - last_turn_ticks) + ", turns: " + str(turns))
        turn_right = (rd > 2000 and abs(gyro_error) < 10) or l > 0
        enc_dif = encoder.data[1] - last_turn_ticks
        if  enc_dif > turn_min_ticks or turns == 0:
            if turn_left:
                rospy.loginfo("Left turn No " + str(turns))
                rospy.loginfo("Left  distance: " + str(ld) + ", line: " + str(l) + ", enc_dif: " + str(enc_dif) + ", gyro error: " + str(gyro_error))
                gyro_target += 90
                turns += 1
                last_turn_ticks = encoder.data[1]                
            elif turn_right:
                rospy.loginfo("Right turn No " + str(turns))
                rospy.loginfo("Right  distance: " + str(rd) + ", line: " + str(l) + ", enc_dif: " + str(enc_dif) + ", gyro error: " + str(gyro_error))
                gyro_target -= 90
                turns += 1
                last_turn_ticks = encoder.data[1]                
        else:
            line = 0
        
        # 2nd step: avoid walls
        if left_distance < min_wall_distance:
            steer.set_steering(100)
            rospy.loginfo('avoiding wall left')
            last_wall_turn_ticks = encoder.data[1]
            
        if right_distance < min_wall_distance:
            steer.set_steering(-100)
            last_wall_turn_ticks = encoder.data[1]
            rospy.loginfo('avoiding wall right')
            
        # 3rd step: avoid pillars
        if encoder.data[1] - last_wall_turn_ticks > wall_ticks_threshold:
            target = get_target(pillar.data[0], pillar.data[4], pillar.data[3], kc=0.5, kh=0.5, min_center=5)
            if target is not None:
                rospy.loginfo("pillar spoted, target=" + str(target))
                last_pillar_turn_ticks = encoder.data[1]
                steer.set_steering(target)
                if target < 0:
                    last_pillar = -1
                elif target > 0:
                    last_pillar = 1
        
        # 4th step: gyro controller
        if encoder.data[1] - last_pillar_turn_ticks > pillar_ticks_threshold and encoder.data[1] - last_wall_turn_ticks > wall_ticks_threshold:
            # Calculate error
            rospy.loginfo('gyro control')
            error = gyro_target - read_angle()
            # Calculate the correction value with the PID object
            pid.update(error)
            u = int(pid.output)
            current_steer = int(min(100, max(u, -100)))
            steer.set_steering(current_steer)

        # # 5th step
        # if last_pillar == 1 and turns == 7:
        #     steer.set_steering(0)
        #     dc_speed(0)
        #     time.sleep(10)
        
    rospy.loginfo("Run2 stopped!")
    dc_speed(0)
    steer.set_steering(0) 

#     # GPIO.cleanup()
# def drive_gyro(speed=50, main_position=0, pid_ks=(0.8, 0, 0)):
#     global line, on_turn, state

#     # Initialise PID object
#     pid = PID(pid_ks[0], pid_ks[1], pid_ks[2])
#     pid.SetPoint = 0
#     pid.setSampleTime(0.005)
#     dc_speed(speed)
#     print("RUNNING")
#     last_turn = 0
#     starting_position = encoder.data
#     start_distance = 0
#     finish_position = 0
#     turns = 0
#     angle_target = main_position
#     direction = 0
#     current_ms = 0
#     last_turn_ms = 0
#     last_pillar_turn_ms = 0
#     counter = 0
#     wall_side = None
#     gyro_target = main_position
#     while not rospy.is_shutdown() and state > 0:
#         # print("Pillar.data", pillar.data)
#         gyro_error = gyro_target - read_angle()
#         ld = left_distance
#         rd = right_distance
#         current_ms = time.time() * 1000
#         target = get_target(pillar.data[0], pillar.data[4], pillar.data[3], kc=0.6, kh=0.6, min_center=22)
#         if target is not None:
#             # print("target:", target)
#             steer.set_steering(target)            
#             last_pillar_turn_ms = current_ms
#         elif current_ms - last_pillar_turn_ms > 500:
#             # Calculate error
#             angle = read_angle()
#             error = angle_target - angle
#             # print(angle, error)
#             # Calculate the correction value with the PID object
#             pid.update(error)
#             u = int(pid.output)
#             current_steer = int(min(100, max(u, -100)))
#             # print("current_steer:", current_steer, "error: ", error)
            
#             steer.set_steering(current_steer)
#         # if line != 0 and not on_turn:
#         #     print("line turn ", turns)
#         #     on_turn = True
#         #     last_turn_ms = current_ms 
#         #     turns += 1
#         #     angle_target += -1*line*90

#         #     if line == 1:
#         #         rgb.color(Color.YELLOW)
#         #     else:
#         #         rgb.color(Color.BLUE)            
#         # if on_turn and current_ms - last_turn_ms > 2000:
#         #     rgb.color(Color.BLACK) 
#         #     on_turn = False
#         #     line = 0
#         if wall_side == None:
#             if rd > 1000:
#                 wall_side = 1
#             if ld > 1000:
#                 wall_side = 0
#         #print("wall side: ", wall_side)
#         if wall_side:
#             if  rd > 2000 and current_ms - last_turn_ms > 3000 and gyro_error<10:
#                 # dc_speed(0)
#                 last_turn_ms = current_ms
#                 angle_target -= 90
#                 print('r')
#                 counter += 1
#         else:
#             if ld > 2000 and current_ms - last_turn_ms > 3000 and gyro_error<10:
#                 ld = current_ms
#                 angle_target += 90
#                 print('l')
#                 counter += 1
#     rospy.loginfo("Run2 stopped!")
#     dc_speed(0)
#     steer.set_steering(0) 
#     # GPIO.cleanup()


# def manuver(a=1):
#     error = read_angle() - (a*90)
#     steer.set_steering(100)
#     dc_speed(40)
#     while read_angle() > error:
#         print(read_angle(), error)
    
#     error = read_angle() - (a*90)
#     steer.set_steering(-100)
#     dc_speed(-40)
#     while read_angle() > error:
#         print(read_angle(), error)
#     dc_speed(0)
#     steer.set_steering(0)


def listener():
    global state

    
    rospy.init_node('run2', anonymous=False)

    rospy.Subscriber("line", Int8, line_callback)
    rospy.Subscriber("lrdistance", Int16MultiArray, distance_callback)
    rospy.Subscriber("gyro_angle", Int16, gyro_callback)
    rospy.Subscriber("pillar_topic", Int16MultiArray, pillar_callback)
    rospy.Subscriber("encoders", Int32MultiArray, encoders_callback)

    rate = rospy.Rate(100) 
    button = Button(pin=21, method_to_run=change_state)
    rgb = RGB()
    rgb.color(Color.RED.value)
    dc_speed(0)
    steer.set_steering(0)
    try:
        time.sleep(10)
        rgb.color(Color.BLUE.value)
        rospy.loginfo("Waiting button ...")
        while state == 0:            
            time.sleep(0.1)
        rgb.color(Color.GREEN.value)
        reset_gyro_angle()
        drive(speed=50, main_position=0, pid_ks=(3, 0.1, 0.02))
        rgb.color(Color.RED.value)
    finally:
        GPIO.cleanup()
    # while not rospy.is_shutdown():
    #     pass

if __name__ == '__main__':
    listener()