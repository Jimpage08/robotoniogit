#!/usr/bin/env python3
import rospy
from std_msgs.msg import Int16MultiArray
from modules.pillar_detection import PillarDetection
import cv2
from camera import Camera

WIDTH = 640 
HEIGHT = 480
FRAMERATE = 60
FLIP_METHOD = 0


cap = Camera()

pillar_detection = PillarDetection(colors={"red":{"h":(173, 5), "s":(101, 255), "v":(50, 255), "num":1}, 
                                        "green":{"h":(67, 97), "s":(60, 255), "v":(50, 255), "num":-1}},
                                        min_area=5000)
pillar_array = Int16MultiArray()

def talker():
    pub = rospy.Publisher('pillar_topic', Int16MultiArray, queue_size=1)
    rospy.init_node('pillar', anonymous=False)
    rate = rospy.Rate(20) 
    error = 0
    while not rospy.is_shutdown(): 

        cv_img = cap.read()
        if cv_img is not None:
            # if not ret_val:
            #     print("Fail to capture")
            #     continue
            result_image, pillar_info = pillar_detection.detect_pillars(cv_img[170:,:], colors=["green", "red"], line=True, error=error)
            # cv2.imshow("CSI Camera", result_image)
            # This also acts as
            # keyCode = cv2.waitKey(1) & 0xFF
            # Stop the program on the ESC key
            # if keyCode == 27:
            #     break   

            pillar_array.data = [pillar_info["color"], pillar_info["cx"], pillar_info["cy"], pillar_info["height"], pillar_info["center"]]
            rospy.loginfo(str(pillar_array.data))
            pub.publish(pillar_array)
        rate.sleep()

if __name__ == '__main__':
    

    try:
        talker()
    except rospy.ROSInterruptException:
        pass