#!/usr/bin/env python3
import steering
import dc
import gyro
import run2
import rospy
import RPi.GPIO as GPIO

rospy.init_node('run2', anonymous=False)
def manuver():
    run2.drive(speed=50)


manuver()
